from odoo import fields, models


class TransitExpense(models.Model):
    _name = 'transit.expense'
    _description = 'Vehicle Expense'
    _rec_name = 'vehicle_id'

    vehicle_id = fields.Many2one('transit.vehicle', string='Vehicle', required=True)
    expense_type = fields.Selection([
        ('toll', 'Toll'),
        ('parking', 'Parking'),
        ('fine', 'Fine'),
        ('other', 'Other'),
    ], string='Expense Type', required=True, default='toll')
    amount = fields.Float(string='Amount', required=True)
    date = fields.Date(string='Date', default=fields.Date.context_today, required=True)
    description = fields.Char(string='Description')
