from odoo import fields, models


class TransitFuelLog(models.Model):
    _name = 'transit.fuel.log'
    _description = 'Fuel Log'
    _rec_name = 'vehicle_id'

    vehicle_id = fields.Many2one('transit.vehicle', string='Vehicle', required=True)
    trip_id = fields.Many2one('transit.trip', string='Related Trip')
    date = fields.Date(string='Date', default=fields.Date.context_today, required=True)
    liters = fields.Float(string='Liters', required=True)
    cost = fields.Float(string='Cost', required=True)
