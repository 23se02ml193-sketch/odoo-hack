from odoo import api, fields, models
from odoo.exceptions import ValidationError


class TransitTrip(models.Model):
    _name = 'transit.trip'
    _description = 'Trip'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'

    name = fields.Char(string='Trip Reference', default='New', copy=False, readonly=True)
    source = fields.Char(string='Source', required=True)
    destination = fields.Char(string='Destination', required=True)

    vehicle_id = fields.Many2one('transit.vehicle', string='Vehicle', required=True, tracking=True)
    driver_id = fields.Many2one('transit.driver', string='Driver', required=True, tracking=True)

    cargo_weight = fields.Float(string='Cargo Weight (kg)', required=True)
    planned_distance = fields.Float(string='Planned Distance (km)', required=True)
    actual_distance = fields.Float(string='Actual Distance (km)')
    fuel_consumed = fields.Float(string='Fuel Consumed (L)')
    final_odometer = fields.Float(string='Final Odometer (km)')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('dispatched', 'Dispatched'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='draft', tracking=True, required=True)

    fuel_log_ids = fields.One2many('transit.fuel.log', 'trip_id', string='Fuel Logs')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('transit.trip') or 'New'
        return super().create(vals_list)

    @api.constrains('cargo_weight', 'vehicle_id')
    def _check_cargo_weight(self):
        for trip in self:
            if trip.vehicle_id and trip.cargo_weight > trip.vehicle_id.max_load_capacity:
                raise ValidationError(
                    'Cargo Weight (%.2f kg) exceeds Vehicle max load capacity (%.2f kg).'
                    % (trip.cargo_weight, trip.vehicle_id.max_load_capacity)
                )

    def action_dispatch(self):
        for trip in self:
            if trip.state != 'draft':
                raise ValidationError('Only Draft trips can be dispatched.')

            vehicle = trip.vehicle_id
            driver = trip.driver_id

            if vehicle.status in ('retired', 'in_shop'):
                raise ValidationError('Vehicle "%s" is %s and cannot be dispatched.'
                                       % (vehicle.name, vehicle.status))
            if vehicle.status == 'on_trip':
                raise ValidationError('Vehicle "%s" is already on another trip.' % vehicle.name)

            if driver.status == 'suspended':
                raise ValidationError('Driver "%s" is suspended and cannot be assigned.' % driver.name)
            if driver.status == 'on_trip':
                raise ValidationError('Driver "%s" is already on another trip.' % driver.name)
            if driver.is_license_expired:
                raise ValidationError('Driver "%s" has an expired license.' % driver.name)

            if trip.cargo_weight > vehicle.max_load_capacity:
                raise ValidationError('Cargo Weight exceeds vehicle max load capacity.')

            vehicle.status = 'on_trip'
            driver.status = 'on_trip'
            trip.state = 'dispatched'

    def action_complete(self):
        for trip in self:
            if trip.state != 'dispatched':
                raise ValidationError('Only Dispatched trips can be completed.')

            if trip.final_odometer and trip.final_odometer < trip.vehicle_id.odometer:
                raise ValidationError('Final odometer cannot be less than current vehicle odometer.')

            if trip.final_odometer:
                trip.actual_distance = trip.final_odometer - trip.vehicle_id.odometer
                trip.vehicle_id.odometer = trip.final_odometer
            elif not trip.actual_distance:
                trip.actual_distance = trip.planned_distance

            trip.vehicle_id.status = 'available'
            trip.driver_id.status = 'available'
            trip.state = 'completed'

    def action_cancel(self):
        for trip in self:
            if trip.state not in ('draft', 'dispatched'):
                raise ValidationError('Only Draft or Dispatched trips can be cancelled.')

            if trip.state == 'dispatched':
                trip.vehicle_id.status = 'available'
                trip.driver_id.status = 'available'

            trip.state = 'cancelled'

    def action_reset_to_draft(self):
        for trip in self:
            if trip.state != 'cancelled':
                raise ValidationError('Only Cancelled trips can be reset to Draft.')
            trip.state = 'draft'
