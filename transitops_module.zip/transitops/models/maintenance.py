from odoo import api, fields, models
from odoo.exceptions import ValidationError


class TransitMaintenance(models.Model):
    _name = 'transit.maintenance'
    _description = 'Maintenance Log'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'

    name = fields.Char(string='Reference', default='New', copy=False, readonly=True)
    vehicle_id = fields.Many2one('transit.vehicle', string='Vehicle', required=True, tracking=True)
    maintenance_type = fields.Selection([
        ('oil_change', 'Oil Change'),
        ('tire_replacement', 'Tire Replacement'),
        ('brake_service', 'Brake Service'),
        ('general_service', 'General Service'),
        ('repair', 'Repair'),
        ('other', 'Other'),
    ], string='Type', required=True, default='general_service')
    description = fields.Text(string='Description')
    cost = fields.Float(string='Cost')
    date_start = fields.Date(string='Start Date', default=fields.Date.context_today, required=True)
    date_end = fields.Date(string='End Date')

    state = fields.Selection([
        ('in_progress', 'In Progress'),
        ('closed', 'Closed'),
    ], string='Status', default='in_progress', tracking=True, required=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('transit.maintenance') or 'New'
        records = super().create(vals_list)
        for record in records:
            if record.state == 'in_progress':
                record.vehicle_id.status = 'in_shop'
        return records

    def action_close(self):
        for record in self:
            if record.state != 'in_progress':
                raise ValidationError('Only in-progress maintenance records can be closed.')
            record.state = 'closed'
            record.date_end = fields.Date.context_today(self)
            if record.vehicle_id.status != 'retired':
                # Only restore to Available if no OTHER open maintenance record exists
                other_open = self.env['transit.maintenance'].search([
                    ('vehicle_id', '=', record.vehicle_id.id),
                    ('state', '=', 'in_progress'),
                    ('id', '!=', record.id),
                ], limit=1)
                if not other_open:
                    record.vehicle_id.status = 'available'

    def action_reopen(self):
        for record in self:
            if record.state != 'closed':
                raise ValidationError('Only closed maintenance records can be reopened.')
            record.state = 'in_progress'
            if record.vehicle_id.status != 'retired':
                record.vehicle_id.status = 'in_shop'
