from odoo import api, fields, models
from odoo.exceptions import ValidationError


class TransitDriver(models.Model):
    _name = 'transit.driver'
    _description = 'Driver'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'

    name = fields.Char(string='Driver Name', required=True, tracking=True)
    license_number = fields.Char(string='License Number', required=True, copy=False, tracking=True)
    license_category = fields.Selection([
        ('lmv', 'LMV - Light Motor Vehicle'),
        ('hmv', 'HMV - Heavy Motor Vehicle'),
        ('mcwg', 'MCWG - Motorcycle with Gear'),
        ('trans', 'Transport'),
    ], string='License Category', required=True)
    license_expiry_date = fields.Date(string='License Expiry Date', required=True, tracking=True)
    contact_number = fields.Char(string='Contact Number')
    safety_score = fields.Float(string='Safety Score', default=100.0,
                                 help='0-100 score reflecting driving safety compliance.')

    status = fields.Selection([
        ('available', 'Available'),
        ('on_trip', 'On Trip'),
        ('off_duty', 'Off Duty'),
        ('suspended', 'Suspended'),
    ], string='Status', default='available', tracking=True, required=True)

    trip_ids = fields.One2many('transit.trip', 'driver_id', string='Trips')
    is_license_expired = fields.Boolean(string='License Expired', compute='_compute_license_expired', store=True)

    _sql_constraints = [
        ('license_number_unique', 'unique(license_number)',
         'License Number must be unique across all drivers!'),
    ]

    @api.depends('license_expiry_date')
    def _compute_license_expired(self):
        today = fields.Date.context_today(self)
        for driver in self:
            driver.is_license_expired = bool(
                driver.license_expiry_date and driver.license_expiry_date < today
            )

    @api.constrains('safety_score')
    def _check_safety_score(self):
        for driver in self:
            if driver.safety_score < 0 or driver.safety_score > 100:
                raise ValidationError('Safety Score must be between 0 and 100.')

    def is_eligible_for_dispatch(self):
        """Returns True if driver can be assigned to a trip right now."""
        self.ensure_one()
        return (
            self.status == 'available'
            and self.license_expiry_date
            and self.license_expiry_date >= fields.Date.context_today(self)
        )
